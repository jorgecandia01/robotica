#ifndef UART_H
#define UART_H
#include <stdint.h> // Define uint32_t

void InicializarUART12 (int baudios );
void putsUART2 ( char *s[]) ;
char getcUART2 ( void ) ;


#endif 