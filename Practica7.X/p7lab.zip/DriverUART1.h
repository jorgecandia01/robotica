#ifndef UART_H
#define UART_H
#include <stdint.h> // Define uint32_t

void InicializarUART1 (int baudios );
void putsUART ( char *s[]) ;
char getcUART ( void ) ;


#endif 























